--WAITFOR : Belirli saat ve dakikada sorgu �al��mas�n� istemiyorsak --belirli zamandan sonra sorgu gelsin istiyorsak
waitfor delay '00:00:05' --5 sn sonra verdi
select*from kitap

waitfor time '18:24:00' --tam bu saatte verdi
select*from kitap