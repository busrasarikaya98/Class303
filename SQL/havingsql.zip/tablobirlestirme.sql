insert into ekle2(adi,soyadi,yasi) --s�tun isimleri 1 den
select adim,soyadim,yasim from ekle1 --bir tabledaki veriyi di�erine aktar�yoruz
select*from ekle2

