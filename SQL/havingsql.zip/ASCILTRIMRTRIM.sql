select ASCII('A') as 'ASCII' --ascide a harfinin degeri 65
select LTRIM('  YAS�N G�KTEPE') as 'AD'--soldaki bosluklar� sildi
select RTRIM('YAS�N G�KTEPE  ') as 'AD' --sagdaki bosluklar� Sildi