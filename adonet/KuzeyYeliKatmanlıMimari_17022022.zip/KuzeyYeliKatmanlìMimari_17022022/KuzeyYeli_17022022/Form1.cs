﻿using KuzeyYeliEntity_17022022;
using KuzeyYeliORM_17022022;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KuzeyYeli_17022022
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Urunler.listele();
            cmbKategoriler.DataSource = Kategoriler.listele();
            cmbKategoriler.DisplayMember = "KategoriAdi";//GÖRÜNEN ADI
            cmbKategoriler.ValueMember = "KategoriID";//TUTTUĞU DEĞER
            cmbTedarikciler.DataSource = Tedarikciler.listele();
            cmbTedarikciler.DisplayMember = "SirketAdi"; //SEÇİMDE GÖRÜNEN ADI
            cmbTedarikciler.ValueMember = "TedarikciID"; //SEÇİMDE TUTTUĞU DEĞER

        }

        private void btnKategori_Click(object sender, EventArgs e)
        {
            Kategori k = new Kategori(); //kategori formu class değil
            k.Show();
        }

        private void btnEkle_Click(object sender, EventArgs e) //urunler csde method oluşturduk
        {
            Urun u = new Urun();
            u.UrunAdi = txtUrunAd.Text;
            u.Stok =(int)nudStok.Value; //decimal tanımlıymış çevirdik
            u.Fiyat = nudFiyat.Value;
            u.KategoriID = (int)cmbKategoriler.SelectedValue;
            u.TedarikciID = (int)cmbTedarikciler.SelectedValue;
            bool sonuc=Urunler.Ekle(u); //ekle dediğimi<de
            if (sonuc)
            {
                MessageBox.Show("Kayıt Başarılı");
                dataGridView1.DataSource = Urunler.listele();
            }
            else
                MessageBox.Show("Kayıt Hatalı");
        }
    }
}
