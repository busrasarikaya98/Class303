﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KuzeyYeliORM_17022022
{
    public static class Tools
    {
        private static SqlConnection baglanti= new SqlConnection(ConfigurationManager.ConnectionStrings["baglanti"].ConnectionString);
        //her classtan ayrı bağlantılar çekmek yerine tek classta bağlantı tanımlayıp diğer classlarda orn sadece tools.baglanti yazarak sql e baglayacagız
        public static SqlConnection Baglanti
        {
            get { return baglanti; }
            set { baglanti = value; }
        }
    }
}
