﻿
namespace _16022022_TelefonRehberi
{
    partial class RehberForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtisim = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtaciklama = new System.Windows.Forms.TextBox();
            this.txtwebadres = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txttel2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txttel1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtsoyisim = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSil = new System.Windows.Forms.Button();
            this.btnGuncelle = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_secaciklama = new System.Windows.Forms.TextBox();
            this.txt_secwebadres = new System.Windows.Forms.TextBox();
            this.txt_secemail = new System.Windows.Forms.TextBox();
            this.txt_sectel2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_sectel1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_secsoyisim = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_secisim = new System.Windows.Forms.TextBox();
            this.list_Rehber = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "İsim";
            // 
            // txtisim
            // 
            this.txtisim.Location = new System.Drawing.Point(86, 31);
            this.txtisim.Name = "txtisim";
            this.txtisim.Size = new System.Drawing.Size(113, 22);
            this.txtisim.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnKaydet);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtaciklama);
            this.groupBox1.Controls.Add(this.txtwebadres);
            this.groupBox1.Controls.Add(this.txtemail);
            this.groupBox1.Controls.Add(this.txttel2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txttel1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtsoyisim);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtisim);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(435, 276);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Yeni Kayıt Ekleme";
            // 
            // btnKaydet
            // 
            this.btnKaydet.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnKaydet.Location = new System.Drawing.Point(86, 207);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(313, 32);
            this.btnKaydet.TabIndex = 7;
            this.btnKaydet.Text = "Kaydet";
            this.btnKaydet.UseVisualStyleBackColor = false;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 154);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 17);
            this.label7.TabIndex = 0;
            this.label7.Text = "Açıklama";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "WebAdres";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(212, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Telefon 2";
            // 
            // txtaciklama
            // 
            this.txtaciklama.Location = new System.Drawing.Point(86, 154);
            this.txtaciklama.Multiline = true;
            this.txtaciklama.Name = "txtaciklama";
            this.txtaciklama.Size = new System.Drawing.Size(313, 47);
            this.txtaciklama.TabIndex = 6;
            // 
            // txtwebadres
            // 
            this.txtwebadres.Location = new System.Drawing.Point(86, 119);
            this.txtwebadres.Name = "txtwebadres";
            this.txtwebadres.Size = new System.Drawing.Size(313, 22);
            this.txtwebadres.TabIndex = 5;
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(86, 88);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(313, 22);
            this.txtemail.TabIndex = 4;
            // 
            // txttel2
            // 
            this.txttel2.Location = new System.Drawing.Point(286, 57);
            this.txttel2.Name = "txttel2";
            this.txttel2.Size = new System.Drawing.Size(113, 22);
            this.txttel2.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Telefon1";
            // 
            // txttel1
            // 
            this.txttel1.Location = new System.Drawing.Point(86, 57);
            this.txttel1.Name = "txttel1";
            this.txttel1.Size = new System.Drawing.Size(113, 22);
            this.txttel1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(216, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Soyisim";
            // 
            // txtsoyisim
            // 
            this.txtsoyisim.Location = new System.Drawing.Point(286, 31);
            this.txtsoyisim.Name = "txtsoyisim";
            this.txtsoyisim.Size = new System.Drawing.Size(113, 22);
            this.txtsoyisim.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSil);
            this.groupBox2.Controls.Add(this.btnGuncelle);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txt_secaciklama);
            this.groupBox2.Controls.Add(this.txt_secwebadres);
            this.groupBox2.Controls.Add(this.txt_secemail);
            this.groupBox2.Controls.Add(this.txt_sectel2);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txt_sectel1);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txt_secsoyisim);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txt_secisim);
            this.groupBox2.Location = new System.Drawing.Point(12, 294);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(435, 276);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Kayıt Güncelle/Sil";
            // 
            // btnSil
            // 
            this.btnSil.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSil.Location = new System.Drawing.Point(260, 207);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(139, 32);
            this.btnSil.TabIndex = 8;
            this.btnSil.Text = "Sil";
            this.btnSil.UseVisualStyleBackColor = false;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnGuncelle.Location = new System.Drawing.Point(86, 207);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(139, 32);
            this.btnGuncelle.TabIndex = 7;
            this.btnGuncelle.Text = "Güncelle";
            this.btnGuncelle.UseVisualStyleBackColor = false;
            this.btnGuncelle.Click += new System.EventHandler(this.btnGuncelle_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 17);
            this.label8.TabIndex = 0;
            this.label8.Text = "Açıklama";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 17);
            this.label9.TabIndex = 0;
            this.label9.Text = "WebAdres";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "Email";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(212, 60);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "Telefon 2";
            // 
            // txt_secaciklama
            // 
            this.txt_secaciklama.Location = new System.Drawing.Point(86, 154);
            this.txt_secaciklama.Multiline = true;
            this.txt_secaciklama.Name = "txt_secaciklama";
            this.txt_secaciklama.Size = new System.Drawing.Size(313, 47);
            this.txt_secaciklama.TabIndex = 6;
            // 
            // txt_secwebadres
            // 
            this.txt_secwebadres.Location = new System.Drawing.Point(86, 119);
            this.txt_secwebadres.Name = "txt_secwebadres";
            this.txt_secwebadres.Size = new System.Drawing.Size(313, 22);
            this.txt_secwebadres.TabIndex = 5;
            // 
            // txt_secemail
            // 
            this.txt_secemail.Location = new System.Drawing.Point(86, 88);
            this.txt_secemail.Name = "txt_secemail";
            this.txt_secemail.Size = new System.Drawing.Size(313, 22);
            this.txt_secemail.TabIndex = 4;
            // 
            // txt_sectel2
            // 
            this.txt_sectel2.Location = new System.Drawing.Point(286, 57);
            this.txt_sectel2.Name = "txt_sectel2";
            this.txt_sectel2.Size = new System.Drawing.Size(113, 22);
            this.txt_sectel2.TabIndex = 3;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 60);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 17);
            this.label12.TabIndex = 0;
            this.label12.Text = "Telefon1";
            // 
            // txt_sectel1
            // 
            this.txt_sectel1.Location = new System.Drawing.Point(86, 57);
            this.txt_sectel1.Name = "txt_sectel1";
            this.txt_sectel1.Size = new System.Drawing.Size(113, 22);
            this.txt_sectel1.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(216, 31);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(56, 17);
            this.label13.TabIndex = 0;
            this.label13.Text = "Soyisim";
            // 
            // txt_secsoyisim
            // 
            this.txt_secsoyisim.Location = new System.Drawing.Point(286, 31);
            this.txt_secsoyisim.Name = "txt_secsoyisim";
            this.txt_secsoyisim.Size = new System.Drawing.Size(113, 22);
            this.txt_secsoyisim.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 34);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(32, 17);
            this.label14.TabIndex = 0;
            this.label14.Text = "İsim";
            // 
            // txt_secisim
            // 
            this.txt_secisim.Location = new System.Drawing.Point(86, 31);
            this.txt_secisim.Name = "txt_secisim";
            this.txt_secisim.Size = new System.Drawing.Size(113, 22);
            this.txt_secisim.TabIndex = 0;
            // 
            // list_Rehber
            // 
            this.list_Rehber.FormattingEnabled = true;
            this.list_Rehber.ItemHeight = 16;
            this.list_Rehber.Location = new System.Drawing.Point(454, 22);
            this.list_Rehber.Name = "list_Rehber";
            this.list_Rehber.Size = new System.Drawing.Size(660, 548);
            this.list_Rehber.TabIndex = 4;
            this.list_Rehber.Click += new System.EventHandler(this.list_Rehber_Click);
            // 
            // RehberForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1126, 626);
            this.Controls.Add(this.list_Rehber);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "RehberForm";
            this.Text = "RehberForm";
            this.Load += new System.EventHandler(this.RehberForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtisim;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnKaydet;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtaciklama;
        private System.Windows.Forms.TextBox txtwebadres;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txttel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txttel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtsoyisim;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.Button btnGuncelle;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_secaciklama;
        private System.Windows.Forms.TextBox txt_secwebadres;
        private System.Windows.Forms.TextBox txt_secemail;
        private System.Windows.Forms.TextBox txt_sectel2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txt_sectel1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txt_secsoyisim;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_secisim;
        private System.Windows.Forms.ListBox list_Rehber;
    }
}